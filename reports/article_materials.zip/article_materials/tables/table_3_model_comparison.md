# Таблица 3. Итоговые метрики Test

| Эксперимент | P, % | R, % | F1, % | mAP@50, % | mAP@50:95, % |
|---|---|---|---|---|---|
| E1 | 57.26 | 71.68 | 63.66 | 59.68 | 27.96 |
| E2 | 64.32 | 62.82 | 63.56 | 53.61 | 27.25 |
| E3 | 60.31 | 75.99 | 67.25 | 72.32 | 37.29 |
| E4 | 57.98 | 75.76 | 65.69 | 71.14 | 36.52 |

Test. P/R/F1: fixed conf=0.25, class-aware one-to-one IoU=0.50; mAP: Ultralytics, conf=0.001.

Источник: `reports/metrics/test_results.json`, `reports/tables/model_comparison.csv`.
